import java.math.BigDecimal;
import java.math.BigInteger;

public class DataTypes {
    public static strictfp void main(String[] args) {

        // Integer
        byte x = 110;
        short x1 = 1000;
        int x2 =  1201201;
        long x3 = 1212211212;

        // Decimal
        float y = 120.56f;
        double y1 = 12.4;

        // Boolean
        boolean flag = true;

        // Text
        char ch = 'B';
        String str = "Brain Mentors";

        BigInteger a = new BigInteger("23243243879879");
        BigInteger b = new BigInteger("56456465464444");
        BigInteger c = a.add(b);
        System.out.println("Sum is : " + c);

        BigDecimal a1 = new BigDecimal("0.453453453");

    }
}
