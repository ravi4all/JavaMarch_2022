public class SecondPr {
    public static void main(String[] args) {
        // System.out.println("Hello");
        // System.out.println("How");
        // System.out.println("are");
        // System.out.println("you ?");

        System.out.print("Hello ");
        System.out.print("How ");
        System.out.print("are ");
        System.out.print("you ?");

    }
}